import java.util.*;

public class MergeIntervals {
    public static void main(String[] args) {
        int[][] intervals = {{1,3},{2,6},{8,10},{15,18}};

        Arrays.sort(intervals, (a,b) -> a[0]-b[0]);

        List<int[]> result = new ArrayList<>();
        int[] current = intervals[0];

        for(int i=1;i<intervals.length;i++){
            if(intervals[i][0] <= current[1]){
                current[1] = Math.max(current[1], intervals[i][1]);
            }else{
                result.add(current);
                current = intervals[i];
            }
        }
        result.add(current);

        System.out.print("[");
        for(int[] i : result){
            System.out.print("[" + i[0] + "," + i[1] + "]");
        }
        System.out.print("]");
    }
}