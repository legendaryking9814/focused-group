import java.util.HashSet;

public class LongestSubstring {

    public static int length(String s){

        HashSet<Character> set = new HashSet<>();

        int left=0,max=0;

        for(int right=0; right<s.length(); right++){

            while(set.contains(s.charAt(right))){
                set.remove(s.charAt(left));
                left++;
            }

            set.add(s.charAt(right));
            max = Math.max(max,right-left+1);
        }

        return max;
    }
}
