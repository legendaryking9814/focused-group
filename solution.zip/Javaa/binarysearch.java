public class binarysearch {
    public static void main(String[] args) {

        int arr[] = {1,2,3,4,5,6,7,8,9};
        int target = 4;

        int left = 0;
        int right = arr.length - 1;
        int result = -1;

        while(left <= right){
            int mid = (left + right) / 2;

            if(arr[mid] == target){
                result = mid;
                break;
            }
            else if(arr[mid] < target)
                left = mid + 1;
            else
                right = mid - 1;
        }

        System.out.println(result);
    }
}
